## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup,echo = FALSE, results='hide',warning=FALSE-------------------------
library(parcelR)
library(lavaan)
library(compositions)

## ----include=TRUE-------------------------------------------------------------
#> First load the data to analyze. Here we are using an example 
#>  data set provided with the function.
#> A response variable that we think is shaped by the microbiome

set.seed(1235)
data("dat")
dat = dat
#> A site x species community matrix
data("otu")
otu = otu

#> Next, transform the community matrix to prepare for analysis. 
#> In our limited evaluation log transformed relative abundances 
#> led to better explanation of the outcome variable, 
#> but any transformation can be substituted here.

#> Add a small value to each element so the log transform does not fail.

otu.t = otu + .0000001 
#> Convert to relative abundances.
otu.ra = otu.t/rowSums(otu.t)
#> Log transform the relative abundances.
otu.ral = log(otu.ra)


## ---- include = TRUE, echo = TRUE---------------------------------------------

#> Check to see if the row names of the dat and otu object match.
all(row.names(dat) == row.names(otu.ral))

## ---- include=TRUE------------------------------------------------------------
#> Now specify the model. Currently, in parcelR this cannot be changed, 
#> so specify this model syntax regardless of your data names.

model = 
'
m =~ p0 + p1 + p2
outcome ~ m 
'

## ----echo = TRUE, results='hide',warning=FALSE--------------------------------
#> Group the species of a site x species community matrix into parcels
#> and returns the summary statistics about performance of each parcel.
p = optimal_parcels(otu.ral, y = dat$duration, n = 100, k = 3, optimizer = "euclidean")

#> Extract the optimal parcel from a community matrix.
p2 = extract_parcel(p, otu.ral, dat$duration)

#> Perform a confirmatory factor analysis using the previously defined model,
#> and the optimal parcel previously extracted.
p3 = cfa(model, p2,  std.lv = TRUE, missing = "fiml")

## ---- include = TRUE, echo = TRUE---------------------------------------------
#> Inspect the model to see how the parcels perform.
inspect(p3, "r2")

## ----echo = TRUE, results='hide',warning=FALSE--------------------------------
#> Create a permuted community matrix where observed 
#> microbiomes are randomly assigned to sites.
dat_perm = permute_matrix(otu.ral, n = 100)
dat_perm2 = rapply(dat_perm, f=function(x) ifelse(is.nan(x),0,x), how="replace" )

#> Identify the optimal organization of species into parcels for the provided 
#> list of community matrices.
parc_perm = parcel_wrap(dat_perm2, y = dat$duration, n = 100, k = 3)

#> Conduct a confirmatory factory analysis for the specified model applied to
#> each parceling scheme for each submatrix identified.
cfa_compare_perm = cfa_wrap(parc_perm, model, otu)

