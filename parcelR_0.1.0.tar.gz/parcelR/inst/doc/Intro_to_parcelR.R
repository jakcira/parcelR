## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include=FALSE, echo=FALSE, results='hide'-------------------------------
library(ggplot2)
library(parcelR)

## ----include=TRUE-------------------------------------------------------------
#> First load the data to analyze. Here we are using an example 
#> data set provided with the function.
#> A response variable that we think is shaped by the microbiome
set.seed(1235)
data("dat")
dat <- dat
#> A site x species community matrix
data("otu")
otu <- otu

#> Next, transform the community matrix to prepare for analysis. 
#> In our limited evaluation log transformed relative abundances 
#> led to better explanation of the outcome variable, 
#> but any transformation can be substituted here.

#Add a small value to each element so the log transform does not fail.
otu.t <- otu + .0000001 

#> Convert to relative abundances.
otu.ra <- otu.t/rowSums(otu.t)

#> Log transform the relative abundances.
otu.ral <- log(otu.ra)


## ---- include = TRUE, echo = TRUE---------------------------------------------

#> Check to see if the row names of the dat and otu object match.
all(row.names(dat) == row.names(otu.ral))

## ---- include=TRUE------------------------------------------------------------
#> Now specify the model. Currently, in parcelR this can not be changed, 
#> so specify this model syntax regardless of your data names.
model = 
'
m =~ p0 + p1 + p2
outcome ~ m 
'

## ----echo = TRUE, results='hide',warning=FALSE--------------------------------
#> Now split the community matrix into subsets based on the 
#> strength and direction of correlation each species has with y.
#> The rationale for splitting the data is that species may differ
#> in their relationship with y such that different species will be positively, negatively, or uncorrelated with y.
#> Splitting allows separation of these potential effects.

#> For example, here we create submatrices including species that 
#> are positively correlated with y in increments of 0.01
#> in both positive and negative directions.
dat_sub <- submatrices(otu.ral, dat$duration, range = "both", by= 0.01, j = 3, method = "pearson")

#> Next, conducted 1,000 iterations for each sub-matrix of 
#> organizing species into k parcels. 
#> For each sub-matrix identify the best parceling structure. 
#> This is accomplished by identifying the parceling structure 
#> that jointly optimizes the parcels relationship 
#> (intra-parcels correlations and the evenness of those correlations) 
#> and the parcels effect (parcels correlations with y, 
#> and evenness of those correlations).

parc <- parcel_wrap(dat_sub, y = dat$duration, n = 1000, k = 3)

#> Perform confirmatory factor analysis for each parceling structure 
#> for each submatrix, and obtain summary statistics for the single 
#> best candidate parcel for each sub-matrix.

cfa_compare <- cfa_wrap(parc, model, otu)

#> Here we only grab the negative correlations, but similar could be
#> done to isolate the positive submatrix results if we have hypotheses
#> in that direction.
neg <- cfa_compare[grep("negative", names(dat_sub)),]

## ---- include=TRUE, echo=TRUE-------------------------------------------------
#> Now we can identify the single best submatrix and parceling 
#> scheme. We are doing this here by selecting the model that 
#> has the optimal balance of R-square effect on y and includes 
#> species that were detected at as many sites as possible.
neg <- euclid_optimize("r2", "percent_of_sites", neg)
neg

## ---- echo=TRUE, results='hide', warning=FALSE--------------------------------
#> Now that we have identified the best parcelling structure, we 
#> can attempt to improve on its predictive power by re-organizing the 
#> species-assignments among the parcels and comparing resulting 
#> R-squared values.

best <- tune_parcel(model, dat.o = neg, dat.l = dat_sub, dat.p = parc, y = dat$duration, n = 1000, k = 3)

## ---- include=TRUE, echo=TRUE-------------------------------------------------
#> We can look at the loadings of the parcels as well as the latent 
#> variables R-square on y. 
inspect(best[[1]], "r2")

#> We can evaluate if the parcels significantly load onto the 
#> latent variable. Here we are looking to see that the each 
#> of the parcels (p0, p1, and p2) significantly measures
#> (=~) the latent construct, m. We are also looking to see that 
#> outcome is significantly predicted (~) by m.

standardizedsolution(best[[1]])

## ---- include=TRUE, echo=TRUE-------------------------------------------------
#> Record our observed R-squared for comparison to the null distribution
obs_r2 <- unname(inspect(best[[1]], "r2")[4])
cor_threshold <- as.numeric(sub(".* ", "", neg$dataset[1]))

## ---- echo=TRUE, results='hide', warning=FALSE--------------------------------
#> Create n data sets in which species are randomly assigned to y values. 
#> This function will return less than n datasets proportional to the 
#> number of instances in which no correlations above cor_threshold were identified.

dat_perm = permute_matrix(otu, dat$duration, n = 100, cor.threshold = cor_threshold)

#> Identify the best parceling structure for each dataset, then perform 
#> CFA on each. cfa_wrap will report warnings if a model doesn't converge.  
#> This is not unexpected because we are randomly pairing sites with y values 
#> (hosts with phenotypes). We will set those model's R-squared to zero

parc_perm = parcel_wrap(dat_perm, y =dat$duration, n = 100, k = 3)

cfa_compare_perm = cfa_wrap(parc_perm, model, otu)


## ---- echo=FALSE, results='hide', warning=FALSE-------------------------------
cfa_compare_perm$r2[is.na(cfa_compare_perm$r2)] = 0

## ----echo=TRUE, results='hide'------------------------------------------------
#> This is the final p-value reporting the probability of randomly obtaining a 
#> latent construct that explains y as strongly as what we observed. If the p-value 
#> was significant, such as in the case of the example data, then you can use the 
#> resulting model for interpretation. Alternatively you can use the parcels to 
#> define the latent construct in a structural equation model that encompasses 
#> other observed variables you may have in your data set.

pval <- length(which(cfa_compare_perm$r2 > obs_r2))/nrow(cfa_compare_perm)
p <- ggplot(cfa_compare_perm, aes(r2)) + geom_density(adjust = 2/1) + geom_vline(xintercept = obs_r2) +
  theme_bw(base_size = 15) + xlab(bquote('Null Distribution of '*~R^2*'')) + ylab("Density")


## ---- include=TRUE, echo=TRUE, fig.width= 6, fig.height= 5--------------------
p

## ----echo=TRUE, results='hide'------------------------------------------------
#> The following provides a quick way that you can visualize 
#> the parceling performance relative to randomize data sets.
temp1 = parc[[1]][parc[[1]]$submatrix == "negative -0.02",]

p9 = ggplot(temp1, aes(interparcel.score, parcel.effect.score)) + geom_point(size = .8, aes(color = parcel.effect.euclid))  + theme_bw(base_size = 15) 
p9 = p9 + labs(x = "Parcels Strength", y = "Parcels Relationship",color='Distance\nfrom\nOptimum' )+
  scale_color_continuous(breaks = c(1.25,1.00, 0.75, 0.50, 0.25),labels = c(1.25,1.00, 0.75, 0.50, 0.25)) + theme(legend.position = "none") 



## ---- include=TRUE, echo=TRUE, fig.width= 6, fig.height= 5--------------------
p9

