#' @title Parcel Optimizer
#'
#' @description This function groups the species of a site x species community matrix into parcels, conducts confirmatory factor analysis, and returns the summary statistics about performance of each parcel. This function is used internally by \link[parcelR]{parcel_wrap} but can be used on its own for a single community matrix.
#' @param dat A site x species community matrix typically as transformed relative abundances.
#' @param y If provided, is a response variable to which parcels are compared.
#' @param k Is the number of parcels to form from the items.
#' @param n Is the number of random parceling assignment iterations.
#' @param optimizer The method for selecting the best parceling structure, either “r2” or “Euclidean”, the latter of which is default. Euclidean selects the best parcel by that which jointly maximize the relationship among the parcels and the parcel’s relationship with y. r2 selects the structure with the largest R2 from confirmatory factor analysis.
#' @details Returns a list of length two with the first being a list of parcel assignments, and the second a data.frame of parcel statistics. If k = 2 then the interparcels variance statistic is NA, because there is only one pairwise parcel statistic.
#' @examples
#' optimal_parcels(dat = otu.ral, y = y, n = 10, k = 3, optimizer = "euclidean")
#'
#' @export
#'

optimal_parcels = function(dat, y = NULL, k, n, optimizer = "euclidean"){
  #dat is a data.frame or matrix of numeric data, columns are items to be parceled
  #y, if provided is a numeric vector to correlate to each parcel to assess relationship
  #k is the number of parcels to form from the items
  #n is the number of random parceling assignment iterations
  #returns a list of length 2: [1] is a list of parcel assigments, [2] is a data.frame of parcel statistics
  #optimizer is used to select if multiobjective optimizaiton of cfa R2 is used to select the best parceling scheme
  #if k, the number of parcels to form from the items, is 2, then interparcels.variance is NA, because there is only one pw.parcel


  if(!is.null(y)){
    if(length(y) != nrow(dat)){
      stop("length of y is not the same as the number of items - inspect with datacheck")
    }
    if(!is.null(names(y))){
      y = y[row.names(x)]
    }
    df = c()
    zz = list()
    for (w in 1:n){
      z = sample(1:ncol(dat))
      z = split(z, sort(z%%k))
      x = z
      for(i in 1:length(x)){
        x[[i]] = dat[,x[[i]], drop = FALSE]
        x[[i]] = rowMeans(x[[i]])
      }
      x = as.data.frame(do.call(cbind, x))
      names(x) = paste0("p", names(x), sep = "")
      x$outcome = y
      if(optimizer == "r2"){
        mod = tryCatch(cfa(model, x, std.lv = TRUE, missing = "fiml"), error=function(e) e, warning=function(w) w)
        if(is(mod,"warning")) {
          r2 = NA
        } else{
          r2 = inspect(mod, 'r2')[[4]]
        }
      }
      x = x[,-ncol(x)]
      p = cor(x)^2
      p = p[lower.tri(p)]
      names(p) = paste("pw.parcel", rep(1:length(p)))
      o = c(cor(x, y, use = "pairwise.complete.obs", method = "pearson"))
      names(o) = paste("parcel.effect", rep(1:length(o)))
      if(optimizer == "r2"){
        d = data.frame(t(c(p, sum(p), var(p), o, sum(o), var(o))), r2)
      }
      if(optimizer == "euclidean"){
        d = data.frame(t(c(p, sum(p), var(p), o, sum(o), var(o))))
      }
      names(d)[grep("V", names(d))] = c("sum.interparcels.r2", "interparcels.variance", "sum.parcel.effect.r2", "parcel.effect.variance")
      df = rbind(df, d)
      zz = append(zz, list(z))
    }

    df$sper2_nonstandardized = df$sum.parcel.effect.r2
    df$pev_nonstandardized = df$parcel.effect.variance
    df$sir2 = df$sum.interparcels.r2
    df$iv = df$interparcels.variance

    vars = c(names(df)[grep("\\.r2", names(df))], names(df)[grep("variance", names(df))])
    for(i in 1:length(vars)){df[,vars[i]] = pom(df[,vars[i]], add.one = TRUE)    }

    df$interparcel.score = df$sum.interparcels.r2/df$interparcels.variance
    df$parcel.effect.score = df$sum.parcel.effect.r2/df$parcel.effect.variance

    vars = names(df)[grep("score", names(df))]
    for(i in 1:length(vars)){df[,vars[i]] = pom(df[,vars[i]])}

    if(optimizer == "euclidean"){
      df = euclid_optimize("interparcel.score", "parcel.effect.score", df)
    }
    if(optimizer == "r2"){
      df = df[order(df$r2, decreasing = TRUE),]
    }
  }

  if(is.null(y)){
    df = c()
    zz = list()
    for (w in 1:n){
      z = sample(1:ncol(dat))
      z = split(z, sort(z%%k))
      x = z
      for(i in 1:length(x)){
        x[[i]] = dat[,x[[i]], drop = FALSE]
        x[[i]] = rowMeans(x[[i]])
      }
      x = as.data.frame(do.call(cbind, x))
      p = cor(x)^2
      p = p[lower.tri(p)]
      names(p) = paste("pw.parcel", rep(1:length(p)))
      d = data.frame(t(c(p, sum(p), var(p))))
      names(d)[grep("V", names(d))] = c("sum.interparcels.r2", "interparcels.variance")
      df = rbind(df, d)
      zz = append(zz, list(z))
    }
    dis = df
    dis[(nrow(dis) + 1),] = rep(1)
    dis = as.matrix(vegdist(dis[,1:n]))
    look = dis[nrow(dis),]
    rank = sort(look)[-1]
    df$interparcel.euclid = rank[match(names(rank), row.names(df))]
    df =df[order(df$interparcel.euclid),]
  }
  output = vector("list", 2)
  output[[1]] = zz
  output[[2]] = df
  return(output)
}
