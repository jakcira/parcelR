#' @title Proportion of Maximum Transformation
#'
#' @description This function conducts proportion of maximum (POM) transformation on a numeric vector. POM scales the variance from 0 to 1 but does not change the shape of the distribution. This function is used internally by \link[parcelR]{optimal_parcels}.
#' @param var A numeric vector.
#' @param add.one TRUE/FALSE. If provided, adds 1 to all values after transformation. Useful if avoid having a value of zero included in the transformed distribution.
#' @details Returns a vector of values.
#' @seealso  \link[parcelR]{optimal_parcels}
#' @examples
#' pom(rnorm(n = 10, mean = 10))
#' @export
#'

pom = function(var, add.one = FALSE){
  var = var - min(var, na.rm = TRUE)
  var = var/max(var, na.rm = TRUE)
  if(add.one == TRUE){
    var = var + 1
  }
  return(var)
}
