#' @title Parcel Optimizer Wrapper
#'
#' @description This is a wrapper function for \link[parcelR]{optimal_parcels}, enabling the identification of the optimal organization of species into parcels for the provided list of community matrices.
#' @param dat.l A list of site x species community matrices - typically the output of  \link[parcelR]{submatrices}.
#' @param y If provided, is a numeric vector to which each parcel is correlated.
#' @param k Is the number of parcels to form from the items.
#' @param n Is the number of random parceling assignment iterations to identify the optimum.
#' @details Returns a list of length three The first element is a data.frame of parcel statistics, including correlations and variances, both among parcels and to y.  The second element is a list of species parcel assignments. Element three a list of the single best parceling scheme for each submatrix in dat.l.
#' @examples
#' parc <- parcel_wrap(dat_sub, y, n = 1000, k = 3)
#'
#' @export
#'

parcel_wrap = function(dat.l, y = NULL, k, n){
  #dat.l is a list of data frames or matrices of numeric data, columns of these entries are items to be parceled - typically the output of submatrices.R
  #y, if provided is a numeric vector to correlate each parcel with to assess relationships
  #k is the number of parcels to form from the items
  #n is the number of random parceling assignment iterations
  #returns a list of length 3: [1] is a data.frame of parcel statistics, [2] a list of otu parcel assignments, [3] a list of parcels with outcome
  output = vector("list", 3)
  best_parcel_memberships = vector("list", length(dat.l))
  best_parcels = vector("list", length(dat.l))
  global_df = c()
  for(j in 1:length(dat.l)){
    if(ncol(dat.l[[j]]) <= 6){
      w = factorial(ncol(dat.l[[j]]))
      print(paste("starting parceling for submatrix ", j))
      df = optimal_parcels(dat.l[[j]], y, k, n = w, optimizer = "euclidean")
      print(paste("finished parceling for submatrix ", j))
    }
    if(ncol(dat.l[[j]]) > 6){
      print(paste("starting parceling for submatrix ", j))
      df = optimal_parcels(dat.l[[j]], y, k, n, optimizer = "euclidean")
      print(paste("finished parceling for submatrix ", j))
    }
    df[[2]]$submatrix = names(dat.l)[j]
    best_parcel_memberships[[j]] = df[[1]][[as.numeric(row.names(df[[2]])[1])]]
    best_parcel_memberships[[j]] = lapply(best_parcel_memberships[[j]], function(x) names(dat.l[[j]][x]))
    names(best_parcel_memberships)[j] = names(dat.l)[j]
    best_parcels[[j]] = lapply(best_parcel_memberships[[j]], function(x) rowMeans(dat.l[[j]][,x, drop = FALSE]))
    best_parcels[[j]] = as.data.frame(do.call(cbind, best_parcels[[j]]))
    names(best_parcels)[j] = names(dat.l)[j]
    names(best_parcels[[j]]) = paste0("p", names(best_parcels[[j]]), sep = "")
    if(!is.null(y)) {best_parcels[[j]]$outcome = y}
    global_df = rbind(global_df, df[[2]])
    print(paste(j, " of ", length(dat.l), " submatrices optimized",sep = ""))
  }
  output[1][[1]] = global_df
  names(output)[1] = "scores"
  output[2][[1]] = best_parcel_memberships
  names(output)[2] = "memberships"
  output[3][[1]] = best_parcels
  names(output)[3] = "parcels"
  return(output)
}



