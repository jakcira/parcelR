#' @title Parcel Extraction
#'
#' @description The function is used to extract the optimal parcel from a community matrix. Can be used in cases where comparison of submatrices is not wanted, but rather evaluating the effectiveness of parceling on a single matrix.
#' @param dat.op The object produced by  \link[parcelR]{optimal_parcels}.
#' @param dat A site x species community matrix as data frame or matrix containing relative abundance or other transformation.
#' @param y A continuous response variable to which parcels are compared.
#' @details The output is a data frame containing the optimized parcel values and the continuous response variable.
#' @examples
#'
#' p <- optimal_parcels(otu.ral, y = y, n = 100, k = 3, optimizer = "euclidean")
#' p2 <- extract_parcel(p, otu.ral, y)
#' p3 <- lavaan::cfa(model, p2,  std.lv = TRUE, missing = "fiml")
#' inspect(p3, "r2")
#'
#' @export

extract_parcel = function(dat.op, dat, y = NULL){
  #dat.op is the result of optimal_parcels.R
  #dat is a data.frame or matrix of numeric data- typically a site x species community matrix with relative abundance/or other transformation
  best = dat.op[[1]]
  best = lapply(best[[1]], function(x) names(dat)[x])
  best = lapply(best, function(x) rowMeans(dat[,x , drop = FALSE]))
  best = as.data.frame(do.call(cbind, best))
  names(best) = paste0("p", names(best), sep = "")
  if(!is.null(y)) {best$outcome = y}
  return(best)
}
