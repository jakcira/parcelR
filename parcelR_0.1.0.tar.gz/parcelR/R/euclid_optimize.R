#' @title Euclidian Optimizer
#'
#' @description The function jointly optimizes two model variables based on Euclidean distance from theoretical best. This function is used internally to the \link[parcelR]{optimal_parcels} function and for selecting among candidate parceling structures.
#' @param var1 A variable to optimize in conjunction with var2, provided as either a vector, or a quoted column name of data. Typically, one of the summary statistics provided by \link[parcelR]{cfa_wrap}.
#' @param var2 A variable to optimize in conjunction with var1, provided as either a vector, or a quoted column name of data. Typically one of the summary statistics provided by \link[parcelR]{cfa_wrap}.
#' @param data If provided, a data frame containing var1 and var2. Typically the output of  \link[parcelR]{cfa_wrap}.
#' @details The output is a data frame, with each row corresponding to a candidate submatrix parcel set. Rows are ordered based on the joint optimization of var1 and var2.
#' @examples
#'
#' cfa_compare <- euclid_optimize("r2", "percent_of_sites", cfa_compare)
#'
#' @export
#'

euclid_optimize = function(var1, var2, data = NULL){
  #var1 and var2 are vectors of variables to optimize - i.e. find observation that simulateously maximizes both
  #data, if provided is a data.frame containing var1 and var2 - if data is provided, var1 and var2 are called by quoted field name
  if(!is.null(data)){
    var1 = data[,var1]
    var2 = data[,var2]
    euclid = sqrt((1 - var1)^2 + (1 - var2)^2)
    data[,"parcel.effect.euclid"] = euclid
    data = data[order(data$parcel.effect.euclid, decreasing = FALSE),]
    return(data)
  } else{
    parcel.effect.euclid = sqrt((1 - var1)^2 + (1 - var2)^2)
    data = data.frame(var1, var2, parcel.effect.euclid)
    data = data[order(data$parcel.effect.euclid, decreasing = FALSE),]
    return(data)
  }
}
