#' @title Parcel Tuner
#'
#' @description This function attempts to improve the previously identified optimal parceling structure by iteratively reorganizing the parceling structure selecting the structure with the largest CFA R-squared.
#' @param model Model provided in lavaan syntax.
#' @param dat.o Output of  \link[parcelR]{euclid_optimize}, which is the rank ordered candidate parcels for each submatrix.
#' @param dat.l Submatrix list created by \link[parcelR]{submatrices}.
#' @param dat.p The optimized parceling structure for each submatrix identified using \link[parcelR]{parcel_wrap}.
#' @param y A numeric vector containing the response variable.
#' @param n The number of parcels to form from the provided species.
#' @param k The number of iterations of re-organizing species into parcels.
#' @details Returns a list of three elements, with the first as an S4 class lavaan object, the second a data frame of sites by the parcels and outcome, and the third a list of the three parcels and the species that make up the parcels.
#' @examples
#'
#' best <- tune_parcel(model, dat.o = cfa_compare, dat.l = dat_sub, dat.p = parc, y = y, n = 3, k = 1000)
#'
#' @export
#'

tune_parcel = function(model, dat.o, dat.l, dat.p, y, n = 3, k = 1000){
  best = dat.l[[as.numeric(row.names(dat.o)[1])]]
  x = optimal_parcels(best, y, n = n, k = k, optimizer = "r2")
  x = x[[1]][[as.numeric(row.names(x[[2]])[1])]]
  x = lapply(x, function(x) names(best[x]))
  x = lapply(x, function(x) rowMeans(best[,x, drop = FALSE]))
  x = as.data.frame(do.call(cbind, x))
  names(x) = paste0("p", names(x), sep = "")
  x$outcome = y
  test = cfa(model, x, missing = "fiml")
  output = vector("list", 3)
  output[[1]] = test
  output[[2]] = x
  output[[3]] = dat.p[[2]][as.numeric(row.names(dat.o)[1])]
  return(output)
}


