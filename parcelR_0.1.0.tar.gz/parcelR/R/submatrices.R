#' @title Submatrices
#'
#' @description This function is used to create submatrices from an input community matrix (site x species) based on increment correlations with a continuous variable, y. For example, specifying by = 0.05, and range = “positive” wound create separate site x species submatrices including only species with correlations to y of 0.05, 0.10, 0.15, etc or higher until no higher correlation is observed.
#' @param dat A site x species community matrix as a data frame or matrix.
#' @param y A vector of a continuous variable to be correlated with dat. Ordering corresponds to the columns (sites) of dat.
#' @param by The increment for including dat variables based on correlation with y. If set larger than the maximum observed correlation with y, the entire dataset is returned (or only the subset that is positively or negatively correlated with y, depending on range).
#' @param range One of "negative", "positive", or "all" specifying if the community matrix should be subset including only species that are negatively or positively correlated with y. All returns both.
#' @param j The minimum number of species required to be in a submatrix for it to be retained in the output.
#' @param method Correlation method, either “pearson” or “mic” (maximal information coefficient).
#' @details Returns a list of site x species submatrices at each correlation threshold.
#' @examples
#' # see vignette for origin of otu.ral and dat.
#' dat_sub <- submatrices(otu.ral, dat$outcome_var, range = "positive", by= .01, j = 3, method = "pearson")
#'
#' @export
#'

submatrices = function(dat, y, by = 0.01, range = "both", j = 3, method = "pearson"){
  #dat is a data.frame or matrix with columns containing continuous variables to correlate with y- dat is typically a site x species community matrix
  #y is a vector of a continuous variable to be correlated with dat
  #by is the increment size for including dat variables based on correlation with y
  #if by is set larger than the max observed cor with outcome the entire dataset (or the subset that is pos or neg cor'd with
  #outcome is returned (depending on the 'range' argument))
  #if 'by' is set to 0 and 'range' is set to 'both' if returns two matrices- one for pos, one for neg cor with outcome
  #range is one of "negative", "positive", or "all" specifying if the community matrix should be subset
  #based only among dat's that are negatively or positively correlated with y. "all" returns both.
  #j is the minimum number of species required to be in a submatrix for it to be retained in the output
  #method is either pearson or mic and sets the type of correlation

  if (!range %in% c("negative", "positive", "both"))
    stop("'range' argument must be either 'negative', 'positive' or 'both'")
  if(by < 0 | by > 1){
    stop("'by' argument must be a value 0 >= =< 1")
  }
  if(!is.numeric(y)){
    stop("y must be numeric")
  }
  if(!all(sapply(dat, is.numeric))){
    stop("dat must be numeric")
  }

  options(scipen = 999)
  if(method == "pearson"){cor_rank = data.frame(cor(dat, y, use = "pairwise.complete.obs"))}
  if(method == "mic"){cor_rank = mine(dat, y, use = "pairwise.complete.obs")$MIC}

  drop = c()
  if(range == "negative" | range == "both"){
    if(length(which(cor_rank < 0)) == 0){
      stop("no correlations were negative: use range = positive")
    }
    if(by > abs(min(cor_rank[,1])) | by == 0){
      neg_sub = vector("list", 1) #could just do neg_sub = list() I think
      neg_sub[[1]] = dat[,names(which(cor_rank[,1] < 0))] #should make <=?
      names(neg_sub)[1] = paste("negative ", 0, sep = "")
    } else{
      by.n = by
      bins = seq(-1,0,by.n)
      bins = bins[which(bins >= min(cor_rank[,1]))]
      neg_sub = lapply(bins, function(z) z >= cor_rank)
      neg_sub = lapply(neg_sub, function(z) dat[,z, drop = FALSE])

      for(i in length(neg_sub):2){
        if(all(suppressWarnings(colnames(neg_sub[[i]]) == colnames(neg_sub[[(i-1)]])))){
          drop = c(drop, i)
        }
        if(ncol(neg_sub[[i]]) < 3){
          drop = c(drop, i)
        }
      }
      if(ncol(neg_sub[[1]]) < 3){
        drop = c(drop, 1)
      }
      if(!is.null(drop)){
        neg_sub = neg_sub[-drop]
        bins = bins[-drop]
      }
      names(neg_sub) = paste("negative ", round(bins, nchar(by.n) - 2), sep = "")
    }
  }

  drop = c()
  if(range == "positive" | range == "both"){
    if(length(which(cor_rank > 0)) == 0){
      stop("no correlations were positive: use range = negative")
    }
    if(by > abs(max(cor_rank[,1])) | by == 0){
      pos_sub = vector("list", 1)
      pos_sub[[1]] = dat[,names(which(cor_rank[,1] > 0))] #should make >=?
      names(pos_sub)[1] = paste("positive ", 0, sep = "")
    } else {
      by.p = by
      bins = seq(0,1,by.p)
      bins = bins[which(bins <= max(cor_rank[,1]))]
      pos_sub = lapply(bins, function(z) z <= cor_rank)
      pos_sub = lapply(pos_sub, function(z) dat[,z, drop = FALSE])

      for(i in 1:(length(pos_sub)-1)){
        if(all(suppressWarnings(colnames(pos_sub[[i]]) == colnames(pos_sub[[(i+1)]])))){
          drop = c(drop, i)
        }
        if(ncol(pos_sub[[i]]) < 3){
          drop = c(drop, i)
        }
      }
      if(ncol(pos_sub[[length(pos_sub)]]) < 3){
        drop = c(drop, length(pos_sub))
      }
      if(!is.null(drop)){
        pos_sub = pos_sub[-drop]
        bins = bins[-drop]
      }
      names(pos_sub) = paste("positive ", round(bins, nchar(by.p) - 2)   , sep = "")
    }
  }
  if(range == "negative"){
    keep = unlist(lapply(neg_sub, function(x) ncol(x) >= j))
    neg_sub = neg_sub[keep]
    return(neg_sub)}
  if(range == "positive"){
    keep = unlist(lapply(pos_sub, function(x) ncol(x) >= j))
    pos_sub = pos_sub[keep]
    return(pos_sub)}
  if(range == "both"){
    pos_sub = c(neg_sub, pos_sub)
    keep = unlist(lapply(pos_sub, function(x) ncol(x) >= j))
    pos_sub = pos_sub[keep]
    return(pos_sub)
  }
}

# test = submatrices(dat, tt$Digestive.Efficiency, range = "both", by= .01)
# names(test)
# for(i in 1:length(test)){print(dim(test[[i]]))}
