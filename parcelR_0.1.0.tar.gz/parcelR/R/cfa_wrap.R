#' @title CFA Wrapper
#'
#' @description This is a wrapper function for the cfa function from laavan. It will conduct Confirmatory Factory Analysis for the specified model applied to each parceling scheme for each submatrix identified using  \link[parcelR]{parcel_wrap}.
#' @param dat.p The optimized parceling scheme for each submatrix identified by  \link[parcelR]{parcel_wrap}.
#' @param model Model provided in lavaan syntax.
#' @param otu The site x species community matrix containing observations (e.g., read counts).
#' @details The output of the function is a data frame with each row reporting for each submatrix the corresponding CFA p-value, R2, and percentages of species, sites, and observations included in each submatrix.
#' @seealso  \link[parcelR]{parcel_wrap} for prior steps in example.
#' @examples
#' model = `
#' m =~ p0 + p1 + p2
#' outcome ~  m`
#'
#' cfa_compare <- cfa_wrap(parc, model, otu)
#'
#'
#' @export
cfa_wrap = function(dat.p, model, otu){
  #dat.p is the output from parcel_wrap
  #model is a lavaan model
  #otu is a community matrix of read counts
  library(lavaan)

  best_matrices = lapply(dat.p[2][[1]], function(x) otu[,unname(unlist(x))])

  sem_comp = lapply(dat.p[3][[1]], function(x) {
    x = suppressWarnings(cfa(model, x, std.lv = TRUE, missing = "fiml"))
    x = data.frame(p = standardizedsolution(x)[4,7],
               r2 = inspect(x, 'r2')[4])
  })
  sem_comp = do.call("rbind", sem_comp)

  row.names(sem_comp) = NULL
  sem_comp$percent_of_species = sapply(best_matrices, function(x) ncol(x)/ncol(otu))
  sem_comp$percent_of_obervations = sapply(best_matrices, function(x) (sum(otu[,colnames(otu) %in% colnames(x)])/sum(otu)))
  sem_comp$percent_of_sites = sapply(best_matrices, function(x) {
    x = rowSums(otu[,colnames(x)])
    x[x > 0] = 1
    x = sum(x)/length(x)
  })
  sem_comp = data.frame(sapply(sem_comp, as.numeric))
  sem_comp$dataset = names(dat.p[[3]])
  return(sem_comp)
}
