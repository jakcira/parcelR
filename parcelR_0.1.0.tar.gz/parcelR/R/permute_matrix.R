#' @title Permutate Community Matrix
#'
#' @description This function is used to create a permuted community matrix where observed microbiomes are randomly assigned to sites. Optionally, these matrices can then be subset to only include species that achieve a Pearson correlation with another variable above a defined threshold.
#' @param dat A site x species community matrix of read counts.
#' @param y If provided, is a response variable to which species abundances will be compared to and retained if their correlation is greater (when cor.threshold is positive) or lesser (when cor.threshold is negative).
#' @param n Is the number of permuted datasets to return.
#' @param cor.threshold A value between -1 and 1 (cannot be 0) specifying the Pearson correlation threshold for retaining species.
#' @details Returns a list of randomized community matrices, with length equal to n less any instances in which no species exceeded cor.threshold.
#' @examples
#' dat_perm <- permute_matrix(otu, y, n = 1000, cor.threshold = cor_threshold)
#'
#' @export
#'

permute_matrix = function(dat, y = NULL, n, cor.threshold = NULL){
  #this function is used to create a permuted community matrix where observed microbiomes are randomly assigned to sites
  #optionally, these matrices can be subset to only include otus that achieve a correlation with an outcome above a provided threshold
  #dat is a site x species community matrix of read counts
  #y, if provided, is a response variable to that otu abundances will be compared to and retained if >< cor.threshold
  #n is the number of permuted datasets to return
  #cor.threshold is a value between -1 and 1 (can not be 0) specifying to keep only otus with a correlation with y > (if cor.threshold is positive) or < (if cor.threshold is negative) cor.threshold
  #returns a list of randomized community matrices

  if(!is.null(y) & is.null(cor.threshold)){
    stop("y is provided but cor.threshold is not")
  }
  if(is.null(y) & !is.null(cor.threshold)){
    stop("cor.threshold is provided but y is not")
  }
  if(!is.null(cor.threshold)){
    if(cor.threshold == 0){
      stop("cor.threshold cannot be 0")
    }
  }

  dat_perm = vector("list", n)

  for(i in 1:n){
    hold = row.names(dat)
    otu.ral = dat[sample(row.names(dat), replace = FALSE, size = nrow(dat)),]
    row.names(otu.ral) = hold
    otu.ral = otu.ral + .00001
    otu.ral = otu.ral/rowSums(otu.ral)
    otu.ral = log(otu.ral)

    if(!is.null(y)){
      keep = cor(otu.ral, y, use = "pairwise.complete.obs")
      if(cor.threshold >= 0) {
        keep = row.names(keep)[which(keep > cor.threshold)]
      }
      if(cor.threshold <= 0) {
        keep = row.names(keep)[which(keep < cor.threshold)]
      }
      if(length(keep) >= 3){
        otu.ral = otu.ral[,keep]
        dat_perm[[i]] = otu.ral
      }
    }
    if(is.null(y)){
      dat_perm[[i]] = otu.ral
    }
    print(i)
  }
  dat_perm = dat_perm[lengths(dat_perm) != 0]
  names(dat_perm) = paste0("permutation", 1:length(dat_perm), sep = "")
  return(dat_perm)
}
